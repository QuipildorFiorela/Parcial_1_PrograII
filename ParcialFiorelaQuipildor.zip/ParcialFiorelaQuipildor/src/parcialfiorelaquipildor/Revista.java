
package parcialfiorelaquipildor;

public class Revista extends Publicacion implements legible{
    private int numeroDeEdicion;

    public Revista(int numeroDeEdicion, String titulo, int anioDePublicacion) {
        super(titulo, anioDePublicacion);
        this.numeroDeEdicion = numeroDeEdicion;
    }

    @Override
    public String toString() {
        return "Revista{" + "numeroDeEdicion=" + numeroDeEdicion + '}';
    }

    @Override
    public void leer() {
        System.out.println("Leyendo la revista '" + titulo + "' con numero de edicion:  " + numeroDeEdicion);
    }
       
}

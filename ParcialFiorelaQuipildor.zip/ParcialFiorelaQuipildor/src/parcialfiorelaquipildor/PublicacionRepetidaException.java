
package parcialfiorelaquipildor;

public class PublicacionRepetidaException extends Exception{
    public  PublicacionRepetidaException() {
        super("Estas tratando de agregar una publicacion que ya existe en la biblioteca!!");
    }
}

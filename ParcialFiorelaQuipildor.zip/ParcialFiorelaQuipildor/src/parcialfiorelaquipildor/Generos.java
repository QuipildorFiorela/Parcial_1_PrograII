
package parcialfiorelaquipildor;

public enum Generos {
    FICCION,
    NO_FICCION,
    CIENCIA,
    HISTORIA
}

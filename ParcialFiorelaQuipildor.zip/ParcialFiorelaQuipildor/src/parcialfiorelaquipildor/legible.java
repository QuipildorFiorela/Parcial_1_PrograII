
package parcialfiorelaquipildor;

public interface legible {
    public void leer();
}

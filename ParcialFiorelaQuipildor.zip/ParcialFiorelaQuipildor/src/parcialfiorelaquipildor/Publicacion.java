
package parcialfiorelaquipildor;

import java.util.Objects;

public abstract class Publicacion {
    // Atributos
    protected String titulo;
    protected int anioDePublicacion;
    
    // Constructor
    public Publicacion(String titulo, int anioDePublicacion) {
        this.titulo = titulo;
        this.anioDePublicacion = anioDePublicacion;
    }
    

    @Override
    public boolean equals(Object obj) {
        //verifico si ers el mismo tipo de objeto en memoria
        if (this == obj) {
            return true;
        }
        //verifico que el objeto no sea null y sea de tipo publicacion
        if (obj == null) {
            return false;
        }
        // Compara los atributos `titulo` y `anioDePublicacion`, si coinciden, los objetos son iguales
        if (obj instanceof Publicacion other) {
            return titulo.equals(other.titulo) && anioDePublicacion == other.anioDePublicacion;
        }
        return false;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + Objects.hashCode(this.titulo);
        hash = 23 * hash + this.anioDePublicacion;
        return hash;
    }
   
    
    
    }


package parcialfiorelaquipildor;

import java.util.List;

public class Biblioteca {
    
    protected List<Publicacion> publicaciones;

    public Biblioteca(List<Publicacion> publicaciones) {
        this.publicaciones = publicaciones;
    }

    public List<Publicacion> getPublicaciones() {
        return publicaciones;
    }
    
    public void agregarPublicacion(Publicacion publicacion) throws PublicacionRepetidaException {
        if (publicaciones.contains(publicacion)){ // si la lista de publicaciones ya contiene a esa publicacion que se está queriendo agregar, se lanza la excepción
            throw new PublicacionRepetidaException();
        } else {
            publicaciones.add(publicacion);
        }
    }
    
    public void mostrarPublicacion(){
        for (Publicacion p : publicaciones){
            System.out.println(p.toString()); // por cada publicacion que exista en mi lista de publicaciones que me muestre su toString.
        }
    }
    
    public void leerPublicacion(){
        for (Publicacion p : publicaciones){
            if (p instanceof legible) { //verifico si la publicacion es una instancia de legible, es decir si implementa la interfaz Legible.
                ((legible) p).leer(); // Si es "legiblle", convierte 'p' a tipo Legible y llama al método 'leer()
            } else{ //Si no es es legible sigfinica que es una ilustración:
                System.out.println("No es posible leer la publicacion '" + p.titulo + "' ya que es una ilustracion.");
            }
        }
    }
    
}

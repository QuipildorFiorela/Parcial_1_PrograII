
package parcialfiorelaquipildor;

import java.util.ArrayList;
import java.util.List;

public class Test {

    public static void main(String[] args) {
        
        List<Publicacion> listaPublicaciones = new ArrayList<>(); //Lista de publicaciones
        
        
        Biblioteca biblioteca = new Biblioteca(listaPublicaciones);  // Instancia de la biblioteca

         Publicacion libro1 = new Libro("Lolita", 1955, "Vladimir Nabokov", Generos.FICCION);
        Publicacion libro2 = new Libro("El origen de las especies", 1859, "Charles Darwin", Generos.CIENCIA);
        Publicacion revista1 = new Revista(101, "Vogue", 1995);
        Publicacion revista2 = new Revista(205, "TeenVogue", 1995);
        Publicacion ilu1 = new Ilustracion("Fiore", 25.5, 15.8,  "Arte de Fio", 2005);
        Publicacion ilu2 = new Ilustracion("Van Gohg", 100.1, 50.5,  "StarryNight", 1889);
        
        
        try {
            biblioteca.agregarPublicacion(libro1);
            biblioteca.agregarPublicacion(libro2);
            biblioteca.agregarPublicacion(revista1);
            biblioteca.agregarPublicacion(ilu1);
            biblioteca.agregarPublicacion(ilu2);
            
            biblioteca.agregarPublicacion(libro2); //agrego un duplicado para verificar que se lance la excepción de publicación repetida
        } catch (PublicacionRepetidaException e){
            System.out.println(e.getMessage()); //busco el msj de la instancia creada en el metodo agregar publicación, y lo lanza si se catchea una publicación repetida
        }
        
        System.out.println("----------------------------------------------------------");
        System.out.println("Lista de Publicaciones de la Biblioteca: ");
        biblioteca.mostrarPublicacion(); //muestro todas las publicaciones de la bibilioteca
        System.out.println("-----------------------------------------------------------");
        
        System.out.println("Leyendo las Publicaciones Legibles: ");
        biblioteca.leerPublicacion();
        
    }
    
}

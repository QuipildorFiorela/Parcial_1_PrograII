
package parcialfiorelaquipildor;

public class Libro extends Publicacion implements legible {
    private String autor;
    private Generos genero;

    public Libro(String titulo, int anioDePublicacion, String autor, Generos genero) {
        super(titulo, anioDePublicacion);
        this.autor = autor;
        this.genero = genero;
    }

    @Override
    public String toString() {
        return "Libro{" + "autor=" + autor + ", genero=" + genero + '}';
    }

    @Override
    public void leer() {
        System.out.println("Leyendo el libro '" + titulo + "' de " + autor);
    }
   
    
}
